package test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;


public class TestWC{
    
    private static final String FILENAME_TEST = "output_test.txt";
    
    
    /**
     * failure test case
     * @throws IOException
     */
	  @Test
	   public void testWebCrawlerDepth() throws IOException {
	     String url = "www.tutorialspoint.com";
	     BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME_TEST));
	     String exceptionMsg = "";
	     try {
			new WebCrawler().getPageLinks(url, 0,0, bw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			exceptionMsg = e.getMessage();
			System.err.println(">>>>>>>>>>>>>>>>>"+exceptionMsg);
		}
	     bw.close();
	     int index =  exceptionMsg.indexOf("Malformed URL");
	     boolean flag = false;
	     if(index != -1){
	    	 flag = true;
	     }
	     Assert.assertEquals(false, flag);
	   }
	  
	  /**
	   * success test case
	   * @throws IOException
	   */
	  @Test
	   public void testWebCrawlerDepth_1() throws IOException {
	     String url = "https://www.tutorialspoint.com";
	     BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME_TEST));
	     String exceptionMsg = "";
	     try {
			new WebCrawler().getPageLinks(url, 0,0, bw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			exceptionMsg = e.getMessage();
			System.err.println(">>>>>>>>>>>>>>>>>"+exceptionMsg);
		}
	     bw.close();	
	     
	     if(exceptionMsg.equals("")){
	    	 Assert.assertEquals(true, true);
	     }
	     Assert.assertEquals(true, false);
	   }
	  
	  //test case:
	//only http, https protocols should be allowed
	//for example ftp protocol should not be allowed
	  
	  
	  
	  //testcase:
	  //check whether the number of images are less than or equal to depth of the images
	  //depth can be configured in properties file
	  
	  
	  //testcase:
	  //check whether the number of web url links are less than or equal to the depth of the urls
	  //depth can be configured in properties file
	  
	  
	  //testcase:
	  //check whether any other file formats (.java, .class, .jar, .war, .ear, .zip, .tar ) are not present in the output file other than images link
	  
	  //testcase:
	  //if the webpage url is not working for the main links for example if we get response as 500 server side error, server is in down state
	  //then images or sub pages href links, should not be displayed.
	  
	  //note:
	  //instead of jsoup we can use URL, URLConnection class of java to connect to web url
	  
}
