package test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebCrawler {
    private static final int MAX_DEPTH = 2;
    private static final int MAX_DEPTH_IMAGES = 5;
    private static final String FILENAME = "output.txt";
    private HashSet<String> links;
    private HashSet<String> images;

    public WebCrawler() {
        links = new HashSet<String>();
        images = new HashSet<String>();
    }

    public void getPageLinks(String URL, int depth, int depthImages, BufferedWriter bw) throws Exception {
       
        	
        	
        	final String newline = System.lineSeparator();
			if ((!links.contains(URL) && (depth < MAX_DEPTH))) {
			    System.out.println(">> Depth: " + depth + " [" + URL + "]");
			    try {
			        links.add(URL);
			        bw.write(">> Depth: " + depth + " [" + URL + "]");
			        bw.write(newline);
			       // bw.flush();
			        Document document = Jsoup.connect(URL).get();
			        Elements linksOnPage = document.select("a[href]");
			        Elements imgsOnPage = document.select("img[src$=.png]");
			        depthImages = 0;
			        for (Element element : imgsOnPage) {
			        	//Element link = doc.select("a").first();
			        	String linkImg = element.attr("src"); // "http://example.com/"
			        	String htmlIMG = element.html();
			        	if ((!images.contains(linkImg) && (depthImages < MAX_DEPTH_IMAGES))) {
			        		System.out.println("linkImg = "+linkImg);
				        	bw.write(linkImg);
				        	bw.write(newline);
				            //bw.flush();
				        	depthImages++;
			        	}	
			        	else{
			        		break;
			        	}
					}

			        depth++;
			        for (Element page : linksOnPage) {
			            getPageLinks(page.attr("abs:href"), depth,depthImages,bw);
			        }
			        bw.flush();
			        //bw.close();
			    } catch (IOException e) {
			        System.err.println("For '" + URL + "': " + e.getMessage());
			    }
			}
			
			System.out.println("Done");
		
    }

    public static void main(String[] args) throws Exception{
    	try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(FILENAME));
			new WebCrawler().getPageLinks("http://www.tutorialspoint.com", 0,0, bw);
			bw.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!"+e.getMessage());
			e.printStackTrace();
		}
    }
}
